export interface RsData<T> {
    resultCode: string;
    msg: string;
    data: T;
}
